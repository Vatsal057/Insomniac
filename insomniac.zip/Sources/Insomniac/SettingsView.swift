import SwiftUI
import KeyboardShortcuts

struct SettingsView: View {
    @State private var manager = SleepManager.shared

    var body: some View {
        Form {
            // MARK: Behaviour
            Section("Behaviour") {
                Toggle("Activate when Insomniac launches", isOn: $manager.activateOnLaunch)
                Toggle("Deactivate when Mac goes to sleep", isOn: $manager.deactivateOnManualSleep)
            }

            // MARK: Keyboard Shortcut
            Section("Keyboard Shortcut") {
                KeyboardShortcuts.Recorder("Toggle sleep prevention:", name: .toggleSleep)
                Text("Default: ⌘⌥I  —  works system-wide even when another app is in front.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .formStyle(.grouped)
        .frame(width: 380)
        // Let the Form size its own height; no fixed height needed
        .fixedSize(horizontal: false, vertical: true)
    }
}

#Preview {
    SettingsView()
}
