import AppKit
import SwiftUI
import KeyboardShortcuts

@MainActor
final class StatusBarController {
    private var statusItem: NSStatusItem
    private var sleepManager = SleepManager.shared
    
    private var menu = NSMenu()
    
    init() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        
        if let button = statusItem.button {
            button.action = #selector(handleAction(_:))
            button.target = self
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
            updateIcon()
        }
        
        setupMenu()
        setupObservation()
    }
    
    private func setupObservation() {
        _ = withObservationTracking {
            sleepManager.isSleepDisabled
        } onChange: { [weak self] in
            Task { @MainActor in
                self?.updateIcon()
                self?.setupMenu()
                self?.setupObservation() // Re-subscribe for continuous tracking
            }
        }
    }
    
    func updateIcon() {
        if let button = statusItem.button {
            let imageName = sleepManager.isSleepDisabled ? "bolt.fill" : "zzz"
            button.image = NSImage(systemSymbolName: imageName, accessibilityDescription: "Insomniac")
        }
    }
    
    private func setupMenu() {
        menu = NSMenu()
        
        let statusText = NSMenuItem(title: "Sleep Prevention: \(sleepManager.isSleepDisabled ? "ON" : "OFF")", action: nil, keyEquivalent: "")
        statusText.isEnabled = false
        menu.addItem(statusText)
        
        menu.addItem(NSMenuItem.separator())
        
        let toggleItem = NSMenuItem(title: sleepManager.isSleepDisabled ? "Re-enable Sleep" : "Disable Sleep", action: #selector(toggleSleep), keyEquivalent: "t")
        toggleItem.target = self
        menu.addItem(toggleItem)
        
        let settingsItem = NSMenuItem(title: "Settings…", action: #selector(openSettings), keyEquivalent: ",")
        settingsItem.target = self
        menu.addItem(settingsItem)
        
        menu.addItem(NSMenuItem.separator())
        
        menu.addItem(NSMenuItem(title: "Quit Insomniac", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"))
    }
    
    @objc private func handleAction(_ sender: NSStatusBarButton) {
        let event = NSApp.currentEvent
        
        if event?.type == .rightMouseUp || (event?.type == .leftMouseUp && event?.modifierFlags.contains(.control) == true) {
            menu.popUp(positioning: nil, at: NSPoint(x: 0, y: sender.frame.height), in: sender)
        } else {
            sleepManager.toggleSleep()
        }
    }
    
    @objc private func toggleSleep() {
        sleepManager.toggleSleep()
    }
    
    @objc private func openSettings() {
        // In SwiftUI, we can use SettingsLink, but here we need to open the settings window.
        // For macOS 13+, we can use:
        if #available(macOS 13.0, *) {
            NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
        } else {
            NSApp.sendAction(Selector(("showPreferencesWindow:")), to: nil, from: nil)
        }
    }
}
