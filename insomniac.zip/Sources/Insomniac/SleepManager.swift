import Foundation
import OSLog
import AppKit
import IOKit

@Observable @MainActor
final class SleepManager {
    static let shared = SleepManager()

    private let logger = Logger(subsystem: "com.insomniac.app", category: "SleepManager")

    // MARK: - Persisted preferences

    var activateOnLaunch: Bool {
        get { UserDefaults.standard.bool(forKey: "activateOnLaunch") }
        set { UserDefaults.standard.set(newValue, forKey: "activateOnLaunch") }
    }

    var deactivateOnManualSleep: Bool {
        get { UserDefaults.standard.bool(forKey: "deactivateOnManualSleep") }
        set { UserDefaults.standard.set(newValue, forKey: "deactivateOnManualSleep") }
    }

    // MARK: - State

    private(set) var isSleepDisabled: Bool = false {
        didSet {
            if isSleepDisabled {
                startLidMonitor()
            } else {
                stopLidMonitor()
                DisplayManager.shared.restoreScreen()
            }
        }
    }

    // Cached IOPMrootDomain — looked up once, released in deinit
    nonisolated private let rootDomain: io_service_t

    // Sudo permission cache — only invalidated when a pmset call fails
    private var _hasSudoPermissions: Bool?

    // IOKit lid-close notification
    private var notifyPort: IONotificationPortRef?
    private var lidNotification: io_object_t = 0
    private var dimTask: Task<Void, Never>?

    // System-sleep observer token
    private var sleepObserver: (any NSObjectProtocol)?

    private let batteryKey = "originalDisplaySleepBattery"
    private let acKey      = "originalDisplaySleepAC"
    private var originalDisplaySleepBattery: Int?
    private var originalDisplaySleepAC: Int?

    // MARK: - Init / deinit

    private init() {
        rootDomain = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("IOPMrootDomain"))

        originalDisplaySleepBattery = UserDefaults.standard.object(forKey: batteryKey) as? Int
        originalDisplaySleepAC      = UserDefaults.standard.object(forKey: acKey) as? Int

        setupObservers()
        checkStatus()

        // Activate on launch if preference is set
        if activateOnLaunch {
            Task { await setSleepDisabled(true) }
        }
    }

    deinit {
        if rootDomain != 0 { IOObjectRelease(rootDomain) }
    }

    // MARK: - Observers

    private func setupObservers() {
        // App termination — restore pmset on quit
        NotificationCenter.default.addObserver(
            forName: NSApplication.willTerminateNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                guard let self, self.isSleepDisabled else { return }
                await self.setSleepDisabled(false)
            }
        }

        // System is about to sleep (covers manual sleep: menu, keyboard, hot corner)
        sleepObserver = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.willSleepNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                guard self.deactivateOnManualSleep, self.isSleepDisabled else { return }
                await self.setSleepDisabled(false)
            }
        }
    }

    // MARK: - Lid monitor via IOKit notifications

    private func startLidMonitor() {
        stopLidMonitor()
        notifyPort = IONotificationPortCreate(kIOMainPortDefault)
        guard let port = notifyPort, rootDomain != 0 else { return }

        IONotificationPortSetDispatchQueue(port, DispatchQueue.main)

        let selfPtr = Unmanaged.passRetained(self).toOpaque()

        let kr = IOServiceAddInterestNotification(
            port,
            rootDomain,
            kIOGeneralInterest,
            { refcon, _, _, _ in
                guard let refcon else { return }
                let manager = Unmanaged<SleepManager>.fromOpaque(refcon).takeUnretainedValue()
                Task { @MainActor in manager.handleLidStateChange() }
            },
            selfPtr,
            &lidNotification
        )

        if kr != kIOReturnSuccess {
            logger.error("IOServiceAddInterestNotification failed: \(kr)")
            IONotificationPortDestroy(port)
            notifyPort = nil
            Unmanaged<SleepManager>.fromOpaque(selfPtr).release()
        }
    }

    private func stopLidMonitor() {
        dimTask?.cancel()
        dimTask = nil
        if lidNotification != 0 { IOObjectRelease(lidNotification); lidNotification = 0 }
        if let port = notifyPort { IONotificationPortDestroy(port); notifyPort = nil }
    }

    private func handleLidStateChange() {
        // Always cancel any in-flight dim task first
        dimTask?.cancel()
        dimTask = nil

        if DisplayManager.shared.isLidClosed() {
            dimTask = Task {
                do {
                    // Use structured try — cancellation throws CancellationError, skipping dimScreen
                    try await Task.sleep(for: .seconds(5))
                    DisplayManager.shared.dimScreen()
                } catch {
                    // Cancelled (lid reopened before 5 s) — nothing to do
                }
            }
        } else {
            DisplayManager.shared.restoreScreen()
        }
    }

    // MARK: - Public toggle

    func toggleSleep() {
        Task { await setSleepDisabled(!isSleepDisabled) }
    }

    // MARK: - Status check (reads IORegistry directly — no process spawn)

    func checkStatus() {
        guard rootDomain != 0 else { return }

        if let value = IORegistryEntryCreateCFProperty(
            rootDomain,
            "SleepDisabled" as CFString,
            kCFAllocatorDefault,
            0
        )?.takeRetainedValue() as? NSNumber {
            isSleepDisabled = value.boolValue
            logger.debug("checkStatus via IORegistry: \(self.isSleepDisabled)")
        } else {
            // Rare fallback: pmset parse
            Task { await checkStatusViaPmset() }
        }
    }

    private func checkStatusViaPmset() async {
        let result = await Task.detached(priority: .utility) {
            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/usr/bin/pmset")
            process.arguments = ["-g"]
            let pipe = Pipe()
            process.standardOutput = pipe
            do {
                try process.run()
                let data = pipe.fileHandleForReading.readDataToEndOfFile()
                return String(data: data, encoding: .utf8)
            } catch { return nil }
        }.value

        guard let output = result else { return }
        let lower = output.lowercased()
        isSleepDisabled = lower.contains("sleepdisabled 1")  || lower.contains("sleepdisabled\t1")
                       || lower.contains("disablesleep 1")   || lower.contains("disablesleep\t1")
    }

    // MARK: - pmset helpers (all async — never block @MainActor)

    private func getDisplaySleepValues() async -> (battery: Int?, ac: Int?) {
        await Task.detached(priority: .userInitiated) {
            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/usr/bin/pmset")
            process.arguments = ["-g", "custom"]
            let pipe = Pipe()
            process.standardOutput = pipe
            do {
                try process.run()
                let data = pipe.fileHandleForReading.readDataToEndOfFile()
                if let output = String(data: data, encoding: .utf8) {
                    return SleepManager.parseDisplaySleep(from: output)
                }
            } catch {}
            return (nil, nil)
        }.value
    }

    nonisolated private static func parseDisplaySleep(from output: String) -> (battery: Int?, ac: Int?) {
        var battery: Int?, ac: Int?, section: String?
        for line in output.components(separatedBy: .newlines) {
            let t = line.trimmingCharacters(in: .whitespaces)
            if t.hasSuffix("Power:") { section = t }
            else if t.hasPrefix("displaysleep") {
                let parts = t.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
                if parts.count >= 2, let v = Int(parts[1]) {
                    if section == "Battery Power:" { battery = v }
                    else if section == "AC Power:"  { ac = v }
                }
            }
        }
        return (battery, ac)
    }

    private func setDisplaySleep(battery: Int?, ac: Int?) async {
        if let b = battery { await runSudoPmset(args: ["-b", "displaysleep", String(b)]) }
        if let a = ac      { await runSudoPmset(args: ["-c", "displaysleep", String(a)]) }
    }

    /// Runs sudo pmset asynchronously. Invalidates permission cache on failure.
    @discardableResult
    private func runSudoPmset(args: [String]) async -> Bool {
        let success = await Task.detached(priority: .userInitiated) {
            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/usr/bin/sudo")
            process.arguments = ["/usr/bin/pmset"] + args
            do {
                try process.run()
                process.waitUntilExit()
                return process.terminationStatus == 0
            } catch { return false }
        }.value

        if !success {
            // Permissions may have been revoked — clear cache so next toggle re-checks
            _hasSudoPermissions = nil
            logger.error("sudo pmset \(args.joined(separator: " ")) failed — permission cache cleared")
        }
        return success
    }

    private func hasPermissions() async -> Bool {
        // Return cache if set (both true and false are cached)
        if let cached = _hasSudoPermissions { return cached }

        let result = await Task.detached(priority: .userInitiated) {
            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/usr/bin/sudo")
            process.arguments = ["-n", "/usr/bin/pmset", "-g"]
            let pipe = Pipe(); process.standardOutput = pipe; process.standardError = pipe
            do {
                try process.run(); process.waitUntilExit()
                return process.terminationStatus == 0
            } catch { return false }
        }.value

        _hasSudoPermissions = result   // cache both true and false
        return result
    }

    private func requestPermissions() async -> Bool {
        let username = NSUserName()
        let scriptSource = """
        do shell script "mkdir -p /etc/sudoers.d && echo '\(username) ALL=(ALL) NOPASSWD: /usr/bin/pmset' > /etc/sudoers.d/insomniac && chmod 0440 /etc/sudoers.d/insomniac" with administrator privileges
        """
        return await Task.detached(priority: .userInitiated) {
            var error: NSDictionary?
            guard let script = NSAppleScript(source: scriptSource) else { return false }
            script.executeAndReturnError(&error)
            return error == nil
        }.value
    }

    private func setSleepDisabled(_ disabled: Bool) async {
        var perms = await hasPermissions()
        if !perms {
            perms = await requestPermissions()
        }

        guard perms else {
            logger.error("Failed to acquire required permissions.")
            _hasSudoPermissions = nil
            return
        }
        _hasSudoPermissions = true

        // Update UI immediately for responsiveness
        isSleepDisabled = disabled

        if disabled {
            let current = await getDisplaySleepValues()
            if let battery = current.battery, originalDisplaySleepBattery == nil {
                originalDisplaySleepBattery = battery
                UserDefaults.standard.set(battery, forKey: batteryKey)
            }
            if let ac = current.ac, originalDisplaySleepAC == nil {
                originalDisplaySleepAC = ac
                UserDefaults.standard.set(ac, forKey: acKey)
            }
            await runSudoPmset(args: ["-a", "displaysleep", "0"])
        } else {
            await setDisplaySleep(battery: originalDisplaySleepBattery, ac: originalDisplaySleepAC)
            originalDisplaySleepBattery = nil; originalDisplaySleepAC = nil
            UserDefaults.standard.removeObject(forKey: batteryKey)
            UserDefaults.standard.removeObject(forKey: acKey)
        }

        let value = disabled ? "1" : "0"
        await runSudoPmset(args: ["-a", "disablesleep", value])
    }
}
