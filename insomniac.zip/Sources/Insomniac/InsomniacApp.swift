import SwiftUI
import ServiceManagement
import KeyboardShortcuts

@main
struct InsomniacApp: App {
    @State private var sleepManager = SleepManager.shared
    @State private var statusBarController: StatusBarController?

    init() {
        NSApplication.shared.setActivationPolicy(.accessory)

        // Set default shortcut (Cmd+Option+I) only on first launch
        if KeyboardShortcuts.getShortcut(for: .toggleSleep) == nil {
            KeyboardShortcuts.setShortcut(.init(.i, modifiers: [.command, .option]), for: .toggleSleep)
        }

        // Inline hotkey registration — GlobalHotkeyManager indirection was dead code
        KeyboardShortcuts.onKeyDown(for: .toggleSleep) {
            SleepManager.shared.toggleSleep()
        }

        // Register as login item (macOS 13+, no-ops if already registered)
        try? SMAppService.mainApp.register()
        
        // Initialize status bar controller
        _statusBarController = State(initialValue: StatusBarController())
    }

    var body: some Scene {
        Settings {
            SettingsView()
        }
    }
}
