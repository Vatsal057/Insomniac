import Foundation
import CoreGraphics
import IOKit

@_silgen_name("DisplayServicesSetBrightness")
func DisplayServicesSetBrightness(_ display: CGDirectDisplayID, _ brightness: Float) -> Int32

@_silgen_name("DisplayServicesGetBrightness")
func DisplayServicesGetBrightness(_ display: CGDirectDisplayID, _ brightness: UnsafeMutablePointer<Float>) -> Int32

/// All mutations happen on @MainActor — same context as SleepManager and handleLidStateChange.
@MainActor
final class DisplayManager {
    static let shared = DisplayManager()

    // Cached for the lifetime of the app — no per-call registry traversal
    private let rootDomain: io_service_t

    private var originalBrightness: Float?
    private var isCurrentlyDimmed = false

    private init() {
        rootDomain = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("IOPMrootDomain"))
    }

    deinit {
        if rootDomain != 0 { IOObjectRelease(rootDomain) }
    }

    func isLidClosed() -> Bool {
        guard rootDomain != 0 else { return false }
        return IORegistryEntryCreateCFProperty(
            rootDomain,
            "AppleClamshellState" as CFString,
            kCFAllocatorDefault,
            0
        )?.takeRetainedValue() as? Bool ?? false
    }

    func dimScreen() {
        guard !isCurrentlyDimmed else { return }
        let displayId = CGMainDisplayID()
        var currentBrightness: Float = 0.0
        if DisplayServicesGetBrightness(displayId, &currentBrightness) == 0 {
            originalBrightness = currentBrightness
            _ = DisplayServicesSetBrightness(displayId, 0.0)
            isCurrentlyDimmed = true
        }
    }

    func restoreScreen() {
        guard isCurrentlyDimmed, let brightness = originalBrightness else { return }
        _ = DisplayServicesSetBrightness(CGMainDisplayID(), brightness)
        isCurrentlyDimmed = false
        originalBrightness = nil
    }
}
